import { GoogleGenAI } from "@google/genai";

export async function generateHeroImage() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: "STRICTLY NIGHT TIME. A cinematic, high-quality image of Tehran, Iran skyline at night. Vibrant electric city lights illuminating the dark night sky. NO SUN, NO DAYLIGHT. In the foreground, a glowing electric lightbulb and a red 'MIGA' (Make Iran Great Again) hat. Modern PolitiFi aesthetic.",
        },
      ],
    },
    config: {
      imageConfig: {
            aspectRatio: "1:1",
        },
    },
  });
  
  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
}
