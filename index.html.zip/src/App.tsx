/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Twitter, Send, ExternalLink, Zap, Shield, Flame, Coins, Clock } from 'lucide-react';
import { generateHeroImage } from './services/imageService';

const COUNTDOWN_TARGET = new Date();
COUNTDOWN_TARGET.setDate(COUNTDOWN_TARGET.getDate() + 4);
COUNTDOWN_TARGET.setHours(COUNTDOWN_TARGET.getHours() + 12);
COUNTDOWN_TARGET.setMinutes(COUNTDOWN_TARGET.getMinutes() + 30);

export default function App() {
  const [heroImage, setHeroImage] = useState<string | null>(null);
  const [isImageLoading, setIsImageLoading] = useState(true);
  const [timeLeft, setTimeLeft] = useState({
    days: 4,
    hours: 12,
    minutes: 30,
    seconds: 0
  });

  useEffect(() => {
    const loadHeroImage = async () => {
      try {
        setIsImageLoading(true);
        const img = await generateHeroImage();
        if (img) setHeroImage(img);
      } catch (error) {
        console.error("Failed to generate hero image:", error);
      } finally {
        setIsImageLoading(false);
      }
    };
    loadHeroImage();

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = COUNTDOWN_TARGET.getTime() - now;

      if (distance < 0) {
        clearInterval(timer);
        return;
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen selection:bg-gold selection:text-midnight">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 glass px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gold rounded-full flex items-center justify-center text-midnight font-bold text-xl">
            $IW
          </div>
          <span className="font-display font-bold text-xl tracking-tighter hidden sm:block">$IRANWIN</span>
        </div>
        <div className="flex gap-4">
          <a href="https://x.com/iranwin26?s=21" target="_blank" rel="noopener noreferrer" className="hover:text-gold transition-colors"><Twitter size={20} /></a>
          <a href="#" className="hover:text-gold transition-colors"><Send size={20} /></a>
          <button className="bg-trump-red px-4 py-1.5 rounded-full text-sm font-bold hover:scale-105 transition-transform">
            BUY NOW
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 flex flex-col items-center text-center overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-20">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-trump-red rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-iran-green rounded-full blur-[120px]" />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >
          <h1 className="text-5xl md:text-8xl font-display font-black mb-6 tracking-tighter leading-none">
            $IRANWIN: <span className="text-gradient">THE LIGHTS STAYED ON!</span>
          </h1>
          <p className="text-xl md:text-2xl text-white/80 mb-10 max-w-2xl mx-auto font-medium">
            Trump's 48h ultimatum is up. Diplomacy won. This is the coin of the new 5-day deal.
          </p>

          <div className="relative mb-12 group">
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="relative z-10"
            >
              {isImageLoading ? (
                <div className="w-64 h-64 md:w-96 md:h-96 mx-auto rounded-full border-4 border-gold glass flex items-center justify-center">
                  <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                <img 
                  src={heroImage || "https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?auto=format&fit=crop&w=800&q=80"} 
                  alt="Iran Win Logo - City Lights" 
                  className="w-64 h-64 md:w-96 md:h-96 mx-auto rounded-full border-4 border-gold glow-animation object-cover"
                  referrerPolicy="no-referrer"
                />
              )}
            </motion.div>
            <div className="absolute inset-0 bg-gold/20 blur-3xl rounded-full -z-10 scale-75 group-hover:scale-100 transition-transform duration-500" />
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="#" 
              className="bg-gold text-midnight px-8 py-4 rounded-full font-black text-xl hover:scale-105 hover:shadow-[0_0_30px_rgba(255,215,0,0.4)] transition-all flex items-center justify-center gap-2"
            >
              BUY ON PUMP.FUN <ExternalLink size={20} />
            </a>
            <a 
              href="#story" 
              className="glass px-8 py-4 rounded-full font-bold text-xl hover:bg-white/20 transition-all"
            >
              OUR STORY
            </a>
          </div>
        </motion.div>
      </section>

      {/* Story Section */}
      <section id="story" className="py-24 px-6 bg-white/5">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-4 mb-8">
            <div className="h-px flex-1 bg-linear-to-r from-transparent to-white/20" />
            <h2 className="text-3xl md:text-5xl font-display font-black uppercase italic">The 48h Countdown</h2>
            <div className="h-px flex-1 bg-linear-to-l from-transparent to-white/20" />
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 text-lg text-white/70 leading-relaxed">
              <p>
                The world held its breath. The missiles were primed. The power grid was in the crosshairs. 
                But a deal was made! The lights are still on, and a 5-day window for peace is open.
              </p>
              <p className="text-white font-bold text-xl">
                $IRANWIN is the meme for those betting on the 'Dealmaker' over the 'Warmonger'.
              </p>
              <p>
                Celebrate the art of last-minute diplomacy. While others panic, we build. 
                The lights are ON, the grid is SAFE, and the gains are coming.
              </p>
            </div>
            <div className="glass p-8 rounded-3xl relative overflow-hidden group">
              <Zap className="text-gold absolute -right-4 -bottom-4 w-32 h-32 opacity-10 group-hover:rotate-12 transition-transform" />
              <h3 className="text-2xl font-bold mb-4 text-gold">MIGA: Make Iran Great Again</h3>
              <p className="italic text-white/60">
                "We don't want war, we want deals. The best deals. Everyone said the lights would go out. 
                I said, let's wait 5 more days. And look at that—the lights are beautiful."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Tokenomics Section */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-6xl font-display font-black text-center mb-16">
            TOKENOMICS: <span className="text-gold">THE FAIR DEAL</span>
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: "SUPPLY", value: "1,000,000,000", icon: <Coins className="text-gold" /> },
              { label: "TAX", value: "0% BUY / SELL", icon: <Flame className="text-trump-red" /> },
              { label: "LIQUIDITY", value: "BURNED", icon: <Shield className="text-iran-green" /> },
              { label: "OWNERSHIP", value: "RENOUNCED", icon: <Zap className="text-gold" /> }
            ].map((item, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="glass p-8 rounded-3xl text-center flex flex-col items-center gap-4"
              >
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center">
                  {item.icon}
                </div>
                <div>
                  <div className="text-sm font-bold text-white/50 uppercase tracking-widest mb-1">{item.label}</div>
                  <div className="text-2xl font-black">{item.value}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Countdown Section */}
      <section className="py-24 px-6 bg-linear-to-b from-transparent to-midnight">
        <div className="max-w-4xl mx-auto glass p-12 rounded-[3rem] text-center border-gold/30">
          <h2 className="text-3xl md:text-5xl font-display font-black mb-4">THE NEW DEADLINE</h2>
          <p className="text-gold font-mono mb-12 tracking-widest uppercase">Diplomacy's Last Window</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: "DAYS", value: timeLeft.days },
              { label: "HOURS", value: timeLeft.hours },
              { label: "MINS", value: timeLeft.minutes },
              { label: "SECS", value: timeLeft.seconds }
            ].map((unit, i) => (
              <div key={i} className="bg-midnight/50 p-6 rounded-2xl border border-white/10">
                <div className="text-4xl md:text-6xl font-black font-mono text-white mb-2">
                  {unit.value.toString().padStart(2, '0')}
                </div>
                <div className="text-xs font-bold text-gold tracking-tighter">{unit.label}</div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 flex items-center justify-center gap-2 text-white/40">
            <Clock size={16} />
            <span className="text-sm font-medium">Live countdown to the 5-day extension end</span>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <footer className="py-20 px-6 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl font-display font-black mb-10">JOIN THE MOVEMENT</h2>
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            <a href="#" className="flex items-center gap-2 bg-[#229ED9] px-6 py-3 rounded-full font-bold hover:scale-105 transition-transform">
              <Send size={20} /> JOIN TELEGRAM
            </a>
            <a href="https://x.com/iranwin26?s=21" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-black border border-white/20 px-6 py-3 rounded-full font-bold hover:scale-105 transition-transform">
              <Twitter size={20} /> FOLLOW ON X
            </a>
            <a href="#" className="flex items-center gap-2 bg-gold text-midnight px-6 py-3 rounded-full font-bold hover:scale-105 transition-transform">
              <Coins size={20} /> BUY $IRANWIN
            </a>
          </div>
          
          <div className="pt-10 border-t border-white/10 text-white/30 text-sm">
            <p className="mb-2">© 2026 $IRANWIN. All rights reserved.</p>
            <p className="max-w-md mx-auto">
              $IRANWIN is a memecoin for entertainment purposes only. No intrinsic value. 
              The art of the deal is risky. Don't bet the power grid.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
